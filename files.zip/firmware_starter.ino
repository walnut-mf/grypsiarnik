/*
  Line Runner - starter ESP32 BLE firmware
  -----------------------------------------
  Matches the "Line Runner" Android app. Uses the Nordic UART Service (NUS)
  so the app can find it as a name starting with "LineRunner" and send it
  single-character commands:

    'L'  -> toggle LEFT motor  (clean/test mode)
    'R'  -> toggle RIGHT motor (clean/test mode)
    'S'  -> toggle START       (line-following run mode)

  This is a STARTER sketch: it just toggles pins so you can test the app
  end-to-end before your real line-following logic is ready. Send me your
  actual firmware and I'll merge this BLE layer into it.

  Library needed (Arduino IDE -> Library Manager):
    "NimBLE-Arduino" by h2zero   (lighter and more reliable than the
    built-in ESP32 BLE library)
*/

#include <NimBLEDevice.h>

#define SERVICE_UUID        "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHAR_UUID_RX         "6e400002-b5a3-f393-e0a9-e50e24dcca9e" // phone -> ESP32
#define CHAR_UUID_TX         "6e400003-b5a3-f393-e0a9-e50e24dcca9e" // ESP32 -> phone

// ---- change these to match your wiring ----
#define LEFT_MOTOR_PIN   25
#define RIGHT_MOTOR_PIN  26
#define START_PIN        27   // e.g. enables your main line-following routine

bool leftOn = false;
bool rightOn = false;
bool startOn = false;

NimBLECharacteristic *txChar;

class CommandCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic *pChar) {
    std::string value = pChar->getValue();
    if (value.empty()) return;
    char cmd = value[0];

    switch (cmd) {
      case 'L':
        leftOn = !leftOn;
        digitalWrite(LEFT_MOTOR_PIN, leftOn ? HIGH : LOW);
        break;
      case 'R':
        rightOn = !rightOn;
        digitalWrite(RIGHT_MOTOR_PIN, rightOn ? HIGH : LOW);
        break;
      case 'S':
        startOn = !startOn;
        digitalWrite(START_PIN, startOn ? HIGH : LOW);
        break;
    }

    // optional: notify the app back so it can show real device state
    if (txChar) {
      String ack = String(cmd) + (cmd == 'L' ? (leftOn ? "1" : "0")
                    : cmd == 'R' ? (rightOn ? "1" : "0")
                    : (startOn ? "1" : "0"));
      txChar->setValue(ack.c_str());
      txChar->notify();
    }
  }
};

void setup() {
  Serial.begin(115200);

  pinMode(LEFT_MOTOR_PIN, OUTPUT);
  pinMode(RIGHT_MOTOR_PIN, OUTPUT);
  pinMode(START_PIN, OUTPUT);

  NimBLEDevice::init("LineRunner-01");   // must start with "LineRunner"
  NimBLEServer *server = NimBLEDevice::createServer();
  NimBLEService *service = server->createService(SERVICE_UUID);

  NimBLECharacteristic *rxChar = service->createCharacteristic(
      CHAR_UUID_RX,
      NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR
  );
  rxChar->setCallbacks(new CommandCallbacks());

  txChar = service->createCharacteristic(
      CHAR_UUID_TX,
      NIMBLE_PROPERTY::NOTIFY
  );

  service->start();
  NimBLEAdvertising *advertising = NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->start();

  Serial.println("LineRunner BLE ready, advertising...");
}

void loop() {
  // your actual line-following sensor/motor logic goes here,
  // gated by the startOn flag once you wire it in.
  delay(20);
}
