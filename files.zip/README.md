# Line Runner — setup guide

This is a small installable app (PWA) that talks to your ESP32 over
Bluetooth LE. Three controls: **Clean Left**, **Clean Right** (each toggles
one motor on/off), and **Start** (toggles line-following on/off).

## Why it needs to be hosted (can't just open the file)

Two Android/Chrome rules make this necessary:
1. **Web Bluetooth only works on HTTPS** (or `localhost`) — opening
   `index.html` directly from your phone's file storage won't allow
   Bluetooth to connect.
2. **"Add to Home Screen" only creates a full installable app icon**
   for pages loaded over HTTPS with a linked `manifest.json`.

The fix is free hosting via **GitHub Pages** — takes about 5 minutes.

## Step 1: Put these files on GitHub Pages

1. Create a free GitHub account if you don't have one.
2. Create a new repository, e.g. `line-runner-app`.
3. Upload these 5 files to the repo (drag-and-drop on github.com works):
   - `index.html`
   - `manifest.json`
   - `service-worker.js`
   - `icon-192.png`
   - `icon-512.png`
4. In the repo, go to **Settings → Pages**, set source to the `main`
   branch, root folder, and save.
5. GitHub gives you a URL like:
   `https://yourusername.github.io/line-runner-app/`

## Step 2: Install it on your phone

1. Open that URL in **Chrome on Android**.
2. Tap the **⋮** menu → **Add to Home screen** (Chrome may prompt this
   automatically).
3. You'll get an app icon on your home screen that opens full-screen,
   no browser bar.

## Step 3: Flash your ESP32

`firmware_starter.ino` is a working starter sketch already wired to the
same Bluetooth protocol the app expects. It just toggles 3 GPIO pins so
you can test the whole chain (phone → BLE → ESP32) before your real
line-following code is ready:

- `'L'` → toggles pin 25 (left motor)
- `'R'` → toggles pin 26 (right motor)
- `'S'` → toggles pin 27 (start line-following)

It needs the **NimBLE-Arduino** library (Library Manager in Arduino IDE).
Change the pin numbers to match your motor driver wiring.

Once you have your real firmware, send it over and I'll merge in the same
Bluetooth layer (service/characteristic UUIDs and the L/R/S command
handling) so the app keeps working with it.

## The Bluetooth protocol (for reference)

Uses the standard **Nordic UART Service** — the most common way to add
BLE serial-like communication to an ESP32:

| Role | UUID |
|---|---|
| Service | `6e400001-b5a3-f393-e0a9-e50e24dcca9e` |
| Write (phone → ESP32) | `6e400002-b5a3-f393-e0a9-e50e24dcca9e` |
| Notify (ESP32 → phone) | `6e400003-b5a3-f393-e0a9-e50e24dcca9e` |

The app looks for a device whose name **starts with `LineRunner`** — the
starter firmware advertises as `LineRunner-01`. Keep that prefix in your
own firmware so the app finds it.

Each button tap sends a single character: `L`, `R`, or `S`. The ESP32
starter code toggles the matching pin each time it receives one.
